echo rm -f ../run/403.gcc/ref/input/166.s
rm -f ../run/403.gcc/ref/input/166.s
echo rm -f ../run/403.gcc/ref/input/200.s
rm -f ../run/403.gcc/ref/input/200.s
echo rm -f ../run/403.gcc/ref/input/c-typeck.s
rm -f ../run/403.gcc/ref/input/c-typeck.s
echo rm -f ../run/403.gcc/ref/input/cp-decl.s
rm -f ../run/403.gcc/ref/input/cp-decl.s
echo rm -f ../run/403.gcc/ref/input/expr.s
rm -f ../run/403.gcc/ref/input/expr.s
echo rm -f ../run/403.gcc/ref/input/expr2.s
rm -f ../run/403.gcc/ref/input/expr2.s
echo rm -f ../run/403.gcc/ref/input/g23.s
rm -f ../run/403.gcc/ref/input/g23.s
echo rm -f ../run/403.gcc/ref/input/s04.s
rm -f ../run/403.gcc/ref/input/s04.s
echo rm -f ../run/403.gcc/ref/input/scilab.s
rm -f ../run/403.gcc/ref/input/scilab.s
