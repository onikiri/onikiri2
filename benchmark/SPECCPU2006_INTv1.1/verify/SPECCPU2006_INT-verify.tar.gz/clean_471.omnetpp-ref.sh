echo rm -f ../run/471.omnetpp/ref/input/omnetpp.log
rm -f ../run/471.omnetpp/ref/input/omnetpp.log
echo rm -f ../run/471.omnetpp/ref/input/omnetpp.sca
rm -f ../run/471.omnetpp/ref/input/omnetpp.sca
