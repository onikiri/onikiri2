echo diff -w ../run/429.mcf/ref/input/inp.out ../run/429.mcf/ref/output/inp.out
diff -w ../run/429.mcf/ref/input/inp.out ../run/429.mcf/ref/output/inp.out
echo diff -w ../run/429.mcf/ref/input/mcf.out ../run/429.mcf/ref/output/mcf.out
diff -w ../run/429.mcf/ref/input/mcf.out ../run/429.mcf/ref/output/mcf.out
