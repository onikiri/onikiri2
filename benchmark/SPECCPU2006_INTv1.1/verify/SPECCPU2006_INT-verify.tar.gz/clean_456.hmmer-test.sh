echo rm -f ../run/456.hmmer/test/input/bombesin.out
rm -f ../run/456.hmmer/test/input/bombesin.out
