echo diff -w ../run/464.h264ref/ref/input/foreman_ref_baseline_encodelog.out ../run/464.h264ref/ref/output/foreman_ref_baseline_encodelog.out
diff -w ../run/464.h264ref/ref/input/foreman_ref_baseline_encodelog.out ../run/464.h264ref/ref/output/foreman_ref_baseline_encodelog.out
echo diff -w ../run/464.h264ref/ref/input/foreman_ref_baseline_leakybucketparam.cfg ../run/464.h264ref/ref/output/foreman_ref_baseline_leakybucketparam.cfg
diff -w ../run/464.h264ref/ref/input/foreman_ref_baseline_leakybucketparam.cfg ../run/464.h264ref/ref/output/foreman_ref_baseline_leakybucketparam.cfg
echo diff -w ../run/464.h264ref/ref/input/foreman_ref_main_encodelog.out ../run/464.h264ref/ref/output/foreman_ref_main_encodelog.out
diff -w ../run/464.h264ref/ref/input/foreman_ref_main_encodelog.out ../run/464.h264ref/ref/output/foreman_ref_main_encodelog.out
echo diff -w ../run/464.h264ref/ref/input/foreman_ref_main_leakybucketparam.cfg ../run/464.h264ref/ref/output/foreman_ref_main_leakybucketparam.cfg
diff -w ../run/464.h264ref/ref/input/foreman_ref_main_leakybucketparam.cfg ../run/464.h264ref/ref/output/foreman_ref_main_leakybucketparam.cfg
echo diff -w ../run/464.h264ref/ref/input/sss_main_encodelog.out ../run/464.h264ref/ref/output/sss_main_encodelog.out
diff -w ../run/464.h264ref/ref/input/sss_main_encodelog.out ../run/464.h264ref/ref/output/sss_main_encodelog.out
echo diff -w ../run/464.h264ref/ref/input/sss_main_leakybucketparam.cfg ../run/464.h264ref/ref/output/sss_main_leakybucketparam.cfg
diff -w ../run/464.h264ref/ref/input/sss_main_leakybucketparam.cfg ../run/464.h264ref/ref/output/sss_main_leakybucketparam.cfg
