echo rm -f ../run/403.gcc/test/input/cccp.s
rm -f ../run/403.gcc/test/input/cccp.s
