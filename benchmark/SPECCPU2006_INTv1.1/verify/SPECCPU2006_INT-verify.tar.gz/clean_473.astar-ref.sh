echo rm -f ../run/473.astar/ref/input/BigLakes2048.out
rm -f ../run/473.astar/ref/input/BigLakes2048.out
echo rm -f ../run/473.astar/ref/input/rivers.out
rm -f ../run/473.astar/ref/input/rivers.out
