echo rm -f ../run/473.astar/test/input/lake.out
rm -f ../run/473.astar/test/input/lake.out
