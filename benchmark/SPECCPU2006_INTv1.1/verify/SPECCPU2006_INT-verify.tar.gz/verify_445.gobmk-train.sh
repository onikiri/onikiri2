echo diff -w ../run/445.gobmk/train/input/arb.out ../run/445.gobmk/train/output/arb.out
diff -w ../run/445.gobmk/train/input/arb.out ../run/445.gobmk/train/output/arb.out
echo diff -w ../run/445.gobmk/train/input/arend.out ../run/445.gobmk/train/output/arend.out
diff -w ../run/445.gobmk/train/input/arend.out ../run/445.gobmk/train/output/arend.out
echo diff -w ../run/445.gobmk/train/input/arion.out ../run/445.gobmk/train/output/arion.out
diff -w ../run/445.gobmk/train/input/arion.out ../run/445.gobmk/train/output/arion.out
echo diff -w ../run/445.gobmk/train/input/atari_atari.out ../run/445.gobmk/train/output/atari_atari.out
diff -w ../run/445.gobmk/train/input/atari_atari.out ../run/445.gobmk/train/output/atari_atari.out
echo diff -w ../run/445.gobmk/train/input/blunder.out ../run/445.gobmk/train/output/blunder.out
diff -w ../run/445.gobmk/train/input/blunder.out ../run/445.gobmk/train/output/blunder.out
echo diff -w ../run/445.gobmk/train/input/buzco.out ../run/445.gobmk/train/output/buzco.out
diff -w ../run/445.gobmk/train/input/buzco.out ../run/445.gobmk/train/output/buzco.out
echo diff -w ../run/445.gobmk/train/input/nicklas2.out ../run/445.gobmk/train/output/nicklas2.out
diff -w ../run/445.gobmk/train/input/nicklas2.out ../run/445.gobmk/train/output/nicklas2.out
echo diff -w ../run/445.gobmk/train/input/nicklas4.out ../run/445.gobmk/train/output/nicklas4.out
diff -w ../run/445.gobmk/train/input/nicklas4.out ../run/445.gobmk/train/output/nicklas4.out
