echo diff -w ../run/473.astar/train/input/BigLakes1024.out ../run/473.astar/train/output/BigLakes1024.out
diff -w ../run/473.astar/train/input/BigLakes1024.out ../run/473.astar/train/output/BigLakes1024.out
echo diff -w ../run/473.astar/train/input/rivers1.out ../run/473.astar/train/output/rivers1.out
diff -w ../run/473.astar/train/input/rivers1.out ../run/473.astar/train/output/rivers1.out
