echo diff -w ../run/471.omnetpp/ref/input/omnetpp.log ../run/471.omnetpp/ref/output/omnetpp.log
diff -w ../run/471.omnetpp/ref/input/omnetpp.log ../run/471.omnetpp/ref/output/omnetpp.log
echo diff -w ../run/471.omnetpp/ref/input/omnetpp.sca ../run/471.omnetpp/ref/output/omnetpp.sca
diff -w ../run/471.omnetpp/ref/input/omnetpp.sca ../run/471.omnetpp/ref/output/omnetpp.sca
