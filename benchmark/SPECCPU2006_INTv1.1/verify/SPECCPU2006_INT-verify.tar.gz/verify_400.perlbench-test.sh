echo diff -w ../run/400.perlbench/test/input/append.out ../run/400.perlbench/test/output/append.out
diff -w ../run/400.perlbench/test/input/append.out ../run/400.perlbench/test/output/append.out
echo diff -w ../run/400.perlbench/test/input/args.out ../run/400.perlbench/test/output/args.out
diff -w ../run/400.perlbench/test/input/args.out ../run/400.perlbench/test/output/args.out
echo diff -w ../run/400.perlbench/test/input/arith.out ../run/400.perlbench/test/output/arith.out
diff -w ../run/400.perlbench/test/input/arith.out ../run/400.perlbench/test/output/arith.out
echo diff -w ../run/400.perlbench/test/input/array.out ../run/400.perlbench/test/output/array.out
diff -w ../run/400.perlbench/test/input/array.out ../run/400.perlbench/test/output/array.out
echo diff -w ../run/400.perlbench/test/input/attrs.out ../run/400.perlbench/test/output/attrs.out
diff -w ../run/400.perlbench/test/input/attrs.out ../run/400.perlbench/test/output/attrs.out
echo diff -w ../run/400.perlbench/test/input/auto.out ../run/400.perlbench/test/output/auto.out
diff -w ../run/400.perlbench/test/input/auto.out ../run/400.perlbench/test/output/auto.out
echo diff -w ../run/400.perlbench/test/input/base_cond.out ../run/400.perlbench/test/output/base_cond.out
diff -w ../run/400.perlbench/test/input/base_cond.out ../run/400.perlbench/test/output/base_cond.out
echo diff -w ../run/400.perlbench/test/input/base_pat.out ../run/400.perlbench/test/output/base_pat.out
diff -w ../run/400.perlbench/test/input/base_pat.out ../run/400.perlbench/test/output/base_pat.out
echo diff -w ../run/400.perlbench/test/input/base_term.out ../run/400.perlbench/test/output/base_term.out
diff -w ../run/400.perlbench/test/input/base_term.out ../run/400.perlbench/test/output/base_term.out
echo diff -w ../run/400.perlbench/test/input/bless.out ../run/400.perlbench/test/output/bless.out
diff -w ../run/400.perlbench/test/input/bless.out ../run/400.perlbench/test/output/bless.out
echo diff -w ../run/400.perlbench/test/input/bop.out ../run/400.perlbench/test/output/bop.out
diff -w ../run/400.perlbench/test/input/bop.out ../run/400.perlbench/test/output/bop.out
echo diff -w ../run/400.perlbench/test/input/bproto.out ../run/400.perlbench/test/output/bproto.out
diff -w ../run/400.perlbench/test/input/bproto.out ../run/400.perlbench/test/output/bproto.out
echo diff -w ../run/400.perlbench/test/input/chars.out ../run/400.perlbench/test/output/chars.out
diff -w ../run/400.perlbench/test/input/chars.out ../run/400.perlbench/test/output/chars.out
echo diff -w ../run/400.perlbench/test/input/chop.out ../run/400.perlbench/test/output/chop.out
diff -w ../run/400.perlbench/test/input/chop.out ../run/400.perlbench/test/output/chop.out
echo diff -w ../run/400.perlbench/test/input/cmdopt.out ../run/400.perlbench/test/output/cmdopt.out
diff -w ../run/400.perlbench/test/input/cmdopt.out ../run/400.perlbench/test/output/cmdopt.out
echo diff -w ../run/400.perlbench/test/input/cmp.out ../run/400.perlbench/test/output/cmp.out
diff -w ../run/400.perlbench/test/input/cmp.out ../run/400.perlbench/test/output/cmp.out
echo diff -w ../run/400.perlbench/test/input/comp_term.out ../run/400.perlbench/test/output/comp_term.out
diff -w ../run/400.perlbench/test/input/comp_term.out ../run/400.perlbench/test/output/comp_term.out
echo diff -w ../run/400.perlbench/test/input/concat.out ../run/400.perlbench/test/output/concat.out
diff -w ../run/400.perlbench/test/input/concat.out ../run/400.perlbench/test/output/concat.out
echo diff -w ../run/400.perlbench/test/input/context.out ../run/400.perlbench/test/output/context.out
diff -w ../run/400.perlbench/test/input/context.out ../run/400.perlbench/test/output/context.out
echo diff -w ../run/400.perlbench/test/input/decl.out ../run/400.perlbench/test/output/decl.out
diff -w ../run/400.perlbench/test/input/decl.out ../run/400.perlbench/test/output/decl.out
echo diff -w ../run/400.perlbench/test/input/defins.out ../run/400.perlbench/test/output/defins.out
diff -w ../run/400.perlbench/test/input/defins.out ../run/400.perlbench/test/output/defins.out
echo diff -w ../run/400.perlbench/test/input/delete.out ../run/400.perlbench/test/output/delete.out
diff -w ../run/400.perlbench/test/input/delete.out ../run/400.perlbench/test/output/delete.out
echo diff -w ../run/400.perlbench/test/input/die.out ../run/400.perlbench/test/output/die.out
diff -w ../run/400.perlbench/test/input/die.out ../run/400.perlbench/test/output/die.out
echo diff -w ../run/400.perlbench/test/input/do.out ../run/400.perlbench/test/output/do.out
diff -w ../run/400.perlbench/test/input/do.out ../run/400.perlbench/test/output/do.out
echo diff -w ../run/400.perlbench/test/input/each.out ../run/400.perlbench/test/output/each.out
diff -w ../run/400.perlbench/test/input/each.out ../run/400.perlbench/test/output/each.out
echo diff -w ../run/400.perlbench/test/input/eval.out ../run/400.perlbench/test/output/eval.out
diff -w ../run/400.perlbench/test/input/eval.out ../run/400.perlbench/test/output/eval.out
echo diff -w ../run/400.perlbench/test/input/exists_sub.out ../run/400.perlbench/test/output/exists_sub.out
diff -w ../run/400.perlbench/test/input/exists_sub.out ../run/400.perlbench/test/output/exists_sub.out
echo diff -w ../run/400.perlbench/test/input/exp.out ../run/400.perlbench/test/output/exp.out
diff -w ../run/400.perlbench/test/input/exp.out ../run/400.perlbench/test/output/exp.out
echo diff -w ../run/400.perlbench/test/input/fh.out ../run/400.perlbench/test/output/fh.out
diff -w ../run/400.perlbench/test/input/fh.out ../run/400.perlbench/test/output/fh.out
echo diff -w ../run/400.perlbench/test/input/grep.out ../run/400.perlbench/test/output/grep.out
diff -w ../run/400.perlbench/test/input/grep.out ../run/400.perlbench/test/output/grep.out
echo diff -w ../run/400.perlbench/test/input/gv.out ../run/400.perlbench/test/output/gv.out
diff -w ../run/400.perlbench/test/input/gv.out ../run/400.perlbench/test/output/gv.out
echo diff -w ../run/400.perlbench/test/input/hashwarn.out ../run/400.perlbench/test/output/hashwarn.out
diff -w ../run/400.perlbench/test/input/hashwarn.out ../run/400.perlbench/test/output/hashwarn.out
echo diff -w ../run/400.perlbench/test/input/if.out ../run/400.perlbench/test/output/if.out
diff -w ../run/400.perlbench/test/input/if.out ../run/400.perlbench/test/output/if.out
echo diff -w ../run/400.perlbench/test/input/inc.out ../run/400.perlbench/test/output/inc.out
diff -w ../run/400.perlbench/test/input/inc.out ../run/400.perlbench/test/output/inc.out
echo diff -w ../run/400.perlbench/test/input/index.out ../run/400.perlbench/test/output/index.out
diff -w ../run/400.perlbench/test/input/index.out ../run/400.perlbench/test/output/index.out
echo diff -w ../run/400.perlbench/test/input/int.out ../run/400.perlbench/test/output/int.out
diff -w ../run/400.perlbench/test/input/int.out ../run/400.perlbench/test/output/int.out
echo diff -w ../run/400.perlbench/test/input/join.out ../run/400.perlbench/test/output/join.out
diff -w ../run/400.perlbench/test/input/join.out ../run/400.perlbench/test/output/join.out
echo diff -w ../run/400.perlbench/test/input/length.out ../run/400.perlbench/test/output/length.out
diff -w ../run/400.perlbench/test/input/length.out ../run/400.perlbench/test/output/length.out
echo diff -w ../run/400.perlbench/test/input/lex.out ../run/400.perlbench/test/output/lex.out
diff -w ../run/400.perlbench/test/input/lex.out ../run/400.perlbench/test/output/lex.out
echo diff -w ../run/400.perlbench/test/input/list.out ../run/400.perlbench/test/output/list.out
diff -w ../run/400.perlbench/test/input/list.out ../run/400.perlbench/test/output/list.out
echo diff -w ../run/400.perlbench/test/input/loopctl.out ../run/400.perlbench/test/output/loopctl.out
diff -w ../run/400.perlbench/test/input/loopctl.out ../run/400.perlbench/test/output/loopctl.out
echo diff -w ../run/400.perlbench/test/input/lop.out ../run/400.perlbench/test/output/lop.out
diff -w ../run/400.perlbench/test/input/lop.out ../run/400.perlbench/test/output/lop.out
echo diff -w ../run/400.perlbench/test/input/makerand.out ../run/400.perlbench/test/output/makerand.out
diff -w ../run/400.perlbench/test/input/makerand.out ../run/400.perlbench/test/output/makerand.out
echo diff -w ../run/400.perlbench/test/input/method.out ../run/400.perlbench/test/output/method.out
diff -w ../run/400.perlbench/test/input/method.out ../run/400.perlbench/test/output/method.out
echo diff -w ../run/400.perlbench/test/input/my.out ../run/400.perlbench/test/output/my.out
diff -w ../run/400.perlbench/test/input/my.out ../run/400.perlbench/test/output/my.out
echo diff -w ../run/400.perlbench/test/input/nothr5005.out ../run/400.perlbench/test/output/nothr5005.out
diff -w ../run/400.perlbench/test/input/nothr5005.out ../run/400.perlbench/test/output/nothr5005.out
echo diff -w ../run/400.perlbench/test/input/oct.out ../run/400.perlbench/test/output/oct.out
diff -w ../run/400.perlbench/test/input/oct.out ../run/400.perlbench/test/output/oct.out
echo diff -w ../run/400.perlbench/test/input/op_cond.out ../run/400.perlbench/test/output/op_cond.out
diff -w ../run/400.perlbench/test/input/op_cond.out ../run/400.perlbench/test/output/op_cond.out
echo diff -w ../run/400.perlbench/test/input/op_pat.out ../run/400.perlbench/test/output/op_pat.out
diff -w ../run/400.perlbench/test/input/op_pat.out ../run/400.perlbench/test/output/op_pat.out
echo diff -w ../run/400.perlbench/test/input/ord.out ../run/400.perlbench/test/output/ord.out
diff -w ../run/400.perlbench/test/input/ord.out ../run/400.perlbench/test/output/ord.out
echo diff -w ../run/400.perlbench/test/input/override.out ../run/400.perlbench/test/output/override.out
diff -w ../run/400.perlbench/test/input/override.out ../run/400.perlbench/test/output/override.out
echo diff -w ../run/400.perlbench/test/input/pack.out ../run/400.perlbench/test/output/pack.out
diff -w ../run/400.perlbench/test/input/pack.out ../run/400.perlbench/test/output/pack.out
echo diff -w ../run/400.perlbench/test/input/package.out ../run/400.perlbench/test/output/package.out
diff -w ../run/400.perlbench/test/input/package.out ../run/400.perlbench/test/output/package.out
echo diff -w ../run/400.perlbench/test/input/pos.out ../run/400.perlbench/test/output/pos.out
diff -w ../run/400.perlbench/test/input/pos.out ../run/400.perlbench/test/output/pos.out
echo diff -w ../run/400.perlbench/test/input/push.out ../run/400.perlbench/test/output/push.out
diff -w ../run/400.perlbench/test/input/push.out ../run/400.perlbench/test/output/push.out
echo diff -w ../run/400.perlbench/test/input/quotemeta.out ../run/400.perlbench/test/output/quotemeta.out
diff -w ../run/400.perlbench/test/input/quotemeta.out ../run/400.perlbench/test/output/quotemeta.out
echo diff -w ../run/400.perlbench/test/input/range.out ../run/400.perlbench/test/output/range.out
diff -w ../run/400.perlbench/test/input/range.out ../run/400.perlbench/test/output/range.out
echo diff -w ../run/400.perlbench/test/input/recurse.out ../run/400.perlbench/test/output/recurse.out
diff -w ../run/400.perlbench/test/input/recurse.out ../run/400.perlbench/test/output/recurse.out
echo diff -w ../run/400.perlbench/test/input/redef.out ../run/400.perlbench/test/output/redef.out
diff -w ../run/400.perlbench/test/input/redef.out ../run/400.perlbench/test/output/redef.out
echo diff -w ../run/400.perlbench/test/input/ref.out ../run/400.perlbench/test/output/ref.out
diff -w ../run/400.perlbench/test/input/ref.out ../run/400.perlbench/test/output/ref.out
echo diff -w ../run/400.perlbench/test/input/regexp.out ../run/400.perlbench/test/output/regexp.out
diff -w ../run/400.perlbench/test/input/regexp.out ../run/400.perlbench/test/output/regexp.out
echo diff -w ../run/400.perlbench/test/input/regexp_noamp.out ../run/400.perlbench/test/output/regexp_noamp.out
diff -w ../run/400.perlbench/test/input/regexp_noamp.out ../run/400.perlbench/test/output/regexp_noamp.out
echo diff -w ../run/400.perlbench/test/input/regmesg.out ../run/400.perlbench/test/output/regmesg.out
diff -w ../run/400.perlbench/test/input/regmesg.out ../run/400.perlbench/test/output/regmesg.out
echo diff -w ../run/400.perlbench/test/input/repeat.out ../run/400.perlbench/test/output/repeat.out
diff -w ../run/400.perlbench/test/input/repeat.out ../run/400.perlbench/test/output/repeat.out
echo diff -w ../run/400.perlbench/test/input/reverse.out ../run/400.perlbench/test/output/reverse.out
diff -w ../run/400.perlbench/test/input/reverse.out ../run/400.perlbench/test/output/reverse.out
echo diff -w ../run/400.perlbench/test/input/rs.out ../run/400.perlbench/test/output/rs.out
diff -w ../run/400.perlbench/test/input/rs.out ../run/400.perlbench/test/output/rs.out
echo diff -w ../run/400.perlbench/test/input/sleep.out ../run/400.perlbench/test/output/sleep.out
diff -w ../run/400.perlbench/test/input/sleep.out ../run/400.perlbench/test/output/sleep.out
echo diff -w ../run/400.perlbench/test/input/sort.out ../run/400.perlbench/test/output/sort.out
diff -w ../run/400.perlbench/test/input/sort.out ../run/400.perlbench/test/output/sort.out
echo diff -w ../run/400.perlbench/test/input/splice.out ../run/400.perlbench/test/output/splice.out
diff -w ../run/400.perlbench/test/input/splice.out ../run/400.perlbench/test/output/splice.out
echo diff -w ../run/400.perlbench/test/input/study.out ../run/400.perlbench/test/output/study.out
diff -w ../run/400.perlbench/test/input/study.out ../run/400.perlbench/test/output/study.out
echo diff -w ../run/400.perlbench/test/input/sub_lval.out ../run/400.perlbench/test/output/sub_lval.out
diff -w ../run/400.perlbench/test/input/sub_lval.out ../run/400.perlbench/test/output/sub_lval.out
echo diff -w ../run/400.perlbench/test/input/subst.out ../run/400.perlbench/test/output/subst.out
diff -w ../run/400.perlbench/test/input/subst.out ../run/400.perlbench/test/output/subst.out
echo diff -w ../run/400.perlbench/test/input/subst_amp.out ../run/400.perlbench/test/output/subst_amp.out
diff -w ../run/400.perlbench/test/input/subst_amp.out ../run/400.perlbench/test/output/subst_amp.out
echo diff -w ../run/400.perlbench/test/input/subst_wamp.out ../run/400.perlbench/test/output/subst_wamp.out
diff -w ../run/400.perlbench/test/input/subst_wamp.out ../run/400.perlbench/test/output/subst_wamp.out
echo diff -w ../run/400.perlbench/test/input/tr.out ../run/400.perlbench/test/output/tr.out
diff -w ../run/400.perlbench/test/input/tr.out ../run/400.perlbench/test/output/tr.out
echo diff -w ../run/400.perlbench/test/input/undef.out ../run/400.perlbench/test/output/undef.out
diff -w ../run/400.perlbench/test/input/undef.out ../run/400.perlbench/test/output/undef.out
echo diff -w ../run/400.perlbench/test/input/unshift.out ../run/400.perlbench/test/output/unshift.out
diff -w ../run/400.perlbench/test/input/unshift.out ../run/400.perlbench/test/output/unshift.out
echo diff -w ../run/400.perlbench/test/input/vec.out ../run/400.perlbench/test/output/vec.out
diff -w ../run/400.perlbench/test/input/vec.out ../run/400.perlbench/test/output/vec.out
echo diff -w ../run/400.perlbench/test/input/wantarray.out ../run/400.perlbench/test/output/wantarray.out
diff -w ../run/400.perlbench/test/input/wantarray.out ../run/400.perlbench/test/output/wantarray.out
