echo diff -w ../run/456.hmmer/ref/input/nph3.out ../run/456.hmmer/ref/output/nph3.out
diff -w ../run/456.hmmer/ref/input/nph3.out ../run/456.hmmer/ref/output/nph3.out
echo diff -w ../run/456.hmmer/ref/input/retro.out ../run/456.hmmer/ref/output/retro.out
diff -w ../run/456.hmmer/ref/input/retro.out ../run/456.hmmer/ref/output/retro.out
