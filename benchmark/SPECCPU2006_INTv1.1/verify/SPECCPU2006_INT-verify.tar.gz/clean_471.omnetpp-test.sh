echo rm -f ../run/471.omnetpp/test/input/omnetpp.log
rm -f ../run/471.omnetpp/test/input/omnetpp.log
echo rm -f ../run/471.omnetpp/test/input/omnetpp.sca
rm -f ../run/471.omnetpp/test/input/omnetpp.sca
