echo diff -w ../run/473.astar/ref/input/BigLakes2048.out ../run/473.astar/ref/output/BigLakes2048.out
diff -w ../run/473.astar/ref/input/BigLakes2048.out ../run/473.astar/ref/output/BigLakes2048.out
echo diff -w ../run/473.astar/ref/input/rivers.out ../run/473.astar/ref/output/rivers.out
diff -w ../run/473.astar/ref/input/rivers.out ../run/473.astar/ref/output/rivers.out
