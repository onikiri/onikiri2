echo rm -f ../run/483.xalancbmk/ref/input/ref.out
rm -f ../run/483.xalancbmk/ref/input/ref.out
