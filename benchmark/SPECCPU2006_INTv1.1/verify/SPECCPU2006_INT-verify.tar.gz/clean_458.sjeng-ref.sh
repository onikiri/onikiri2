echo rm -f ../run/458.sjeng/ref/input/ref.out
rm -f ../run/458.sjeng/ref/input/ref.out
