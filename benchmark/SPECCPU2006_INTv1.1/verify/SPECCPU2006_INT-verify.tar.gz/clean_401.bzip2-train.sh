echo rm -f ../run/401.bzip2/train/input/byoudoin.jpg.out
rm -f ../run/401.bzip2/train/input/byoudoin.jpg.out
echo rm -f ../run/401.bzip2/train/input/input.combined.out
rm -f ../run/401.bzip2/train/input/input.combined.out
echo rm -f ../run/401.bzip2/train/input/input.program.out
rm -f ../run/401.bzip2/train/input/input.program.out
