echo diff -w ../run/458.sjeng/train/input/train.out ../run/458.sjeng/train/output/train.out
diff -w ../run/458.sjeng/train/input/train.out ../run/458.sjeng/train/output/train.out
