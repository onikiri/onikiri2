echo diff -w ../run/458.sjeng/test/input/test.out ../run/458.sjeng/test/output/test.out
diff -w ../run/458.sjeng/test/input/test.out ../run/458.sjeng/test/output/test.out
