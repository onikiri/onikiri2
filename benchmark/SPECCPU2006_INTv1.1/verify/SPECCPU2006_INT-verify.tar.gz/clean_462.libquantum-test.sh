echo rm -f ../run/462.libquantum/test/input/test.out
rm -f ../run/462.libquantum/test/input/test.out
