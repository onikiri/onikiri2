echo rm -f ../run/483.xalancbmk/train/input/train.out
rm -f ../run/483.xalancbmk/train/input/train.out
