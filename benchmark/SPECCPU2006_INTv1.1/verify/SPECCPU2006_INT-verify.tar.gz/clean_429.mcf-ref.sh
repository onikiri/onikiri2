echo rm -f ../run/429.mcf/ref/input/inp.out
rm -f ../run/429.mcf/ref/input/inp.out
echo rm -f ../run/429.mcf/ref/input/mcf.out
rm -f ../run/429.mcf/ref/input/mcf.out
