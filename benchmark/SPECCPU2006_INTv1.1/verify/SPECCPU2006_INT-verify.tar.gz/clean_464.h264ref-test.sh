echo rm -f ../run/464.h264ref/test/input/foreman_test_baseline_encodelog.out
rm -f ../run/464.h264ref/test/input/foreman_test_baseline_encodelog.out
echo rm -f ../run/464.h264ref/test/input/foreman_test_baseline_leakybucketparam.cfg
rm -f ../run/464.h264ref/test/input/foreman_test_baseline_leakybucketparam.cfg
