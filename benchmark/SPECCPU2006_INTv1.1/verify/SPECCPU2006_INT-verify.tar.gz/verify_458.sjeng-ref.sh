echo diff -w ../run/458.sjeng/ref/input/ref.out ../run/458.sjeng/ref/output/ref.out
diff -w ../run/458.sjeng/ref/input/ref.out ../run/458.sjeng/ref/output/ref.out
