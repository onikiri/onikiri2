echo diff -w ../run/403.gcc/train/input/integrate.s ../run/403.gcc/train/output/integrate.s
diff -w ../run/403.gcc/train/input/integrate.s ../run/403.gcc/train/output/integrate.s
