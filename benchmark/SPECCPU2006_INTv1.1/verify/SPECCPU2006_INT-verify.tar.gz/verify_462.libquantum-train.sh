echo diff -w ../run/462.libquantum/train/input/train.out ../run/462.libquantum/train/output/train.out
diff -w ../run/462.libquantum/train/input/train.out ../run/462.libquantum/train/output/train.out
