echo diff -w ../run/483.xalancbmk/test/input/test.out ../run/483.xalancbmk/test/output/test.out
diff -w ../run/483.xalancbmk/test/input/test.out ../run/483.xalancbmk/test/output/test.out
