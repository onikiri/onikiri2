echo diff -w ../run/403.gcc/ref/input/166.s ../run/403.gcc/ref/output/166.s
diff -w ../run/403.gcc/ref/input/166.s ../run/403.gcc/ref/output/166.s
echo diff -w ../run/403.gcc/ref/input/200.s ../run/403.gcc/ref/output/200.s
diff -w ../run/403.gcc/ref/input/200.s ../run/403.gcc/ref/output/200.s
echo diff -w ../run/403.gcc/ref/input/c-typeck.s ../run/403.gcc/ref/output/c-typeck.s
diff -w ../run/403.gcc/ref/input/c-typeck.s ../run/403.gcc/ref/output/c-typeck.s
echo diff -w ../run/403.gcc/ref/input/cp-decl.s ../run/403.gcc/ref/output/cp-decl.s
diff -w ../run/403.gcc/ref/input/cp-decl.s ../run/403.gcc/ref/output/cp-decl.s
echo diff -w ../run/403.gcc/ref/input/expr.s ../run/403.gcc/ref/output/expr.s
diff -w ../run/403.gcc/ref/input/expr.s ../run/403.gcc/ref/output/expr.s
echo diff -w ../run/403.gcc/ref/input/expr2.s ../run/403.gcc/ref/output/expr2.s
diff -w ../run/403.gcc/ref/input/expr2.s ../run/403.gcc/ref/output/expr2.s
echo diff -w ../run/403.gcc/ref/input/g23.s ../run/403.gcc/ref/output/g23.s
diff -w ../run/403.gcc/ref/input/g23.s ../run/403.gcc/ref/output/g23.s
echo diff -w ../run/403.gcc/ref/input/s04.s ../run/403.gcc/ref/output/s04.s
diff -w ../run/403.gcc/ref/input/s04.s ../run/403.gcc/ref/output/s04.s
echo diff -w ../run/403.gcc/ref/input/scilab.s ../run/403.gcc/ref/output/scilab.s
diff -w ../run/403.gcc/ref/input/scilab.s ../run/403.gcc/ref/output/scilab.s
