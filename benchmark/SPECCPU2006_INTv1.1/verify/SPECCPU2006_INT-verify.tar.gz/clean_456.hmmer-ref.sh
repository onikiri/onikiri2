echo rm -f ../run/456.hmmer/ref/input/nph3.out
rm -f ../run/456.hmmer/ref/input/nph3.out
echo rm -f ../run/456.hmmer/ref/input/retro.out
rm -f ../run/456.hmmer/ref/input/retro.out
