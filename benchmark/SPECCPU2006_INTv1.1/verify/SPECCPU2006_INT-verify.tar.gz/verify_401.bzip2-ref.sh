echo diff -w ../run/401.bzip2/ref/input/chicken.jpg.out ../run/401.bzip2/ref/output/chicken.jpg.out
diff -w ../run/401.bzip2/ref/input/chicken.jpg.out ../run/401.bzip2/ref/output/chicken.jpg.out
echo diff -w ../run/401.bzip2/ref/input/input.combined.out ../run/401.bzip2/ref/output/input.combined.out
diff -w ../run/401.bzip2/ref/input/input.combined.out ../run/401.bzip2/ref/output/input.combined.out
echo diff -w ../run/401.bzip2/ref/input/input.program.out ../run/401.bzip2/ref/output/input.program.out
diff -w ../run/401.bzip2/ref/input/input.program.out ../run/401.bzip2/ref/output/input.program.out
echo diff -w ../run/401.bzip2/ref/input/input.source.out ../run/401.bzip2/ref/output/input.source.out
diff -w ../run/401.bzip2/ref/input/input.source.out ../run/401.bzip2/ref/output/input.source.out
echo diff -w ../run/401.bzip2/ref/input/liberty.jpg.out ../run/401.bzip2/ref/output/liberty.jpg.out
diff -w ../run/401.bzip2/ref/input/liberty.jpg.out ../run/401.bzip2/ref/output/liberty.jpg.out
echo diff -w ../run/401.bzip2/ref/input/text.html.out ../run/401.bzip2/ref/output/text.html.out
diff -w ../run/401.bzip2/ref/input/text.html.out ../run/401.bzip2/ref/output/text.html.out
