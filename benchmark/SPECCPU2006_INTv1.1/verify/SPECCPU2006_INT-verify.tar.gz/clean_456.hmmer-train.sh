echo rm -f ../run/456.hmmer/train/input/leng100.out
rm -f ../run/456.hmmer/train/input/leng100.out
