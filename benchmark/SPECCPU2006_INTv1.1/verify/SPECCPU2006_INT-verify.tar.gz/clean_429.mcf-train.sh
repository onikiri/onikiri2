echo rm -f ../run/429.mcf/train/input/inp.out
rm -f ../run/429.mcf/train/input/inp.out
echo rm -f ../run/429.mcf/train/input/mcf.out
rm -f ../run/429.mcf/train/input/mcf.out
