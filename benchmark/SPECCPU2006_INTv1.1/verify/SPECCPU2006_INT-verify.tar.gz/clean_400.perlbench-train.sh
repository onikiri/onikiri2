echo rm -f ../run/400.perlbench/train/input/diffmail.2.550.15.24.23.100.out
rm -f ../run/400.perlbench/train/input/diffmail.2.550.15.24.23.100.out
echo rm -f ../run/400.perlbench/train/input/perfect.b.3.out
rm -f ../run/400.perlbench/train/input/perfect.b.3.out
echo rm -f ../run/400.perlbench/train/input/scrabbl.out
rm -f ../run/400.perlbench/train/input/scrabbl.out
echo rm -f ../run/400.perlbench/train/input/splitmail.535.13.25.24.1091.out
rm -f ../run/400.perlbench/train/input/splitmail.535.13.25.24.1091.out
echo rm -f ../run/400.perlbench/train/input/suns.out
rm -f ../run/400.perlbench/train/input/suns.out
echo rm -f ../run/400.perlbench/train/input/validate
rm -f ../run/400.perlbench/train/input/validate
