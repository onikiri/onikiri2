echo diff -w ../run/401.bzip2/train/input/byoudoin.jpg.out ../run/401.bzip2/train/output/byoudoin.jpg.out
diff -w ../run/401.bzip2/train/input/byoudoin.jpg.out ../run/401.bzip2/train/output/byoudoin.jpg.out
echo diff -w ../run/401.bzip2/train/input/input.combined.out ../run/401.bzip2/train/output/input.combined.out
diff -w ../run/401.bzip2/train/input/input.combined.out ../run/401.bzip2/train/output/input.combined.out
echo diff -w ../run/401.bzip2/train/input/input.program.out ../run/401.bzip2/train/output/input.program.out
diff -w ../run/401.bzip2/train/input/input.program.out ../run/401.bzip2/train/output/input.program.out
