echo diff -w ../run/471.omnetpp/test/input/omnetpp.log ../run/471.omnetpp/test/output/omnetpp.log
diff -w ../run/471.omnetpp/test/input/omnetpp.log ../run/471.omnetpp/test/output/omnetpp.log
echo diff -w ../run/471.omnetpp/test/input/omnetpp.sca ../run/471.omnetpp/test/output/omnetpp.sca
diff -w ../run/471.omnetpp/test/input/omnetpp.sca ../run/471.omnetpp/test/output/omnetpp.sca
