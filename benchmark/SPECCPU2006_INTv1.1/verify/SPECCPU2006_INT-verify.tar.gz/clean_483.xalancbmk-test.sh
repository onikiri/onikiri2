echo rm -f ../run/483.xalancbmk/test/input/test.out
rm -f ../run/483.xalancbmk/test/input/test.out
