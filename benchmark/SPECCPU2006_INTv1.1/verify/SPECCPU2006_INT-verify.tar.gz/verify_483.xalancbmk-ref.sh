echo diff -w ../run/483.xalancbmk/ref/input/ref.out ../run/483.xalancbmk/ref/output/ref.out
diff -w ../run/483.xalancbmk/ref/input/ref.out ../run/483.xalancbmk/ref/output/ref.out
