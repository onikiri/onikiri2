echo diff -w ../run/445.gobmk/ref/input/13x13.out ../run/445.gobmk/ref/output/13x13.out
diff -w ../run/445.gobmk/ref/input/13x13.out ../run/445.gobmk/ref/output/13x13.out
echo diff -w ../run/445.gobmk/ref/input/nngs.out ../run/445.gobmk/ref/output/nngs.out
diff -w ../run/445.gobmk/ref/input/nngs.out ../run/445.gobmk/ref/output/nngs.out
echo diff -w ../run/445.gobmk/ref/input/score2.out ../run/445.gobmk/ref/output/score2.out
diff -w ../run/445.gobmk/ref/input/score2.out ../run/445.gobmk/ref/output/score2.out
echo diff -w ../run/445.gobmk/ref/input/trevorc.out ../run/445.gobmk/ref/output/trevorc.out
diff -w ../run/445.gobmk/ref/input/trevorc.out ../run/445.gobmk/ref/output/trevorc.out
echo diff -w ../run/445.gobmk/ref/input/trevord.out ../run/445.gobmk/ref/output/trevord.out
diff -w ../run/445.gobmk/ref/input/trevord.out ../run/445.gobmk/ref/output/trevord.out
