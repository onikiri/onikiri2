echo diff -w ../run/483.xalancbmk/train/input/train.out ../run/483.xalancbmk/train/output/train.out
diff -w ../run/483.xalancbmk/train/input/train.out ../run/483.xalancbmk/train/output/train.out
