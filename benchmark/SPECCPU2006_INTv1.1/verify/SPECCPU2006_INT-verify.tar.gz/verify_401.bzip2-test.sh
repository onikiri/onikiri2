echo diff -w ../run/401.bzip2/test/input/dryer.jpg.out ../run/401.bzip2/test/output/dryer.jpg.out
diff -w ../run/401.bzip2/test/input/dryer.jpg.out ../run/401.bzip2/test/output/dryer.jpg.out
echo diff -w ../run/401.bzip2/test/input/input.program.out ../run/401.bzip2/test/output/input.program.out
diff -w ../run/401.bzip2/test/input/input.program.out ../run/401.bzip2/test/output/input.program.out
