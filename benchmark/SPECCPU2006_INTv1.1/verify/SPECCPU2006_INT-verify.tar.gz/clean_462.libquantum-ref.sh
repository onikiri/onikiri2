echo rm -f ../run/462.libquantum/ref/input/ref.out
rm -f ../run/462.libquantum/ref/input/ref.out
