echo diff -w ../run/456.hmmer/test/input/bombesin.out ../run/456.hmmer/test/output/bombesin.out
diff -w ../run/456.hmmer/test/input/bombesin.out ../run/456.hmmer/test/output/bombesin.out
