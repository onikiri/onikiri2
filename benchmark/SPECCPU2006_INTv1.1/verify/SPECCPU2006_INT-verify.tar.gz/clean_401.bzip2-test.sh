echo rm -f ../run/401.bzip2/test/input/dryer.jpg.out
rm -f ../run/401.bzip2/test/input/dryer.jpg.out
echo rm -f ../run/401.bzip2/test/input/input.program.out
rm -f ../run/401.bzip2/test/input/input.program.out
