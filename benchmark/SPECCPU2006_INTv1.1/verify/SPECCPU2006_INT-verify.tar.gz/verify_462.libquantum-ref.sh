echo diff -w ../run/462.libquantum/ref/input/ref.out ../run/462.libquantum/ref/output/ref.out
diff -w ../run/462.libquantum/ref/input/ref.out ../run/462.libquantum/ref/output/ref.out
