echo diff -w ../run/400.perlbench/ref/input/checkspam.2500.5.25.11.150.1.1.1.1.out ../run/400.perlbench/ref/output/checkspam.2500.5.25.11.150.1.1.1.1.out
diff -w ../run/400.perlbench/ref/input/checkspam.2500.5.25.11.150.1.1.1.1.out ../run/400.perlbench/ref/output/checkspam.2500.5.25.11.150.1.1.1.1.out
echo diff -w ../run/400.perlbench/ref/input/diffmail.4.800.10.17.19.300.out ../run/400.perlbench/ref/output/diffmail.4.800.10.17.19.300.out
diff -w ../run/400.perlbench/ref/input/diffmail.4.800.10.17.19.300.out ../run/400.perlbench/ref/output/diffmail.4.800.10.17.19.300.out
echo diff -w ../run/400.perlbench/ref/input/splitmail.1600.12.26.16.4500.out ../run/400.perlbench/ref/output/splitmail.1600.12.26.16.4500.out
diff -w ../run/400.perlbench/ref/input/splitmail.1600.12.26.16.4500.out ../run/400.perlbench/ref/output/splitmail.1600.12.26.16.4500.out
