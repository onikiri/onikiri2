echo diff -w ../run/400.perlbench/train/input/diffmail.2.550.15.24.23.100.out ../run/400.perlbench/train/output/diffmail.2.550.15.24.23.100.out
diff -w ../run/400.perlbench/train/input/diffmail.2.550.15.24.23.100.out ../run/400.perlbench/train/output/diffmail.2.550.15.24.23.100.out
echo diff -w ../run/400.perlbench/train/input/perfect.b.3.out ../run/400.perlbench/train/output/perfect.b.3.out
diff -w ../run/400.perlbench/train/input/perfect.b.3.out ../run/400.perlbench/train/output/perfect.b.3.out
echo diff -w ../run/400.perlbench/train/input/scrabbl.out ../run/400.perlbench/train/output/scrabbl.out
diff -w ../run/400.perlbench/train/input/scrabbl.out ../run/400.perlbench/train/output/scrabbl.out
echo diff -w ../run/400.perlbench/train/input/splitmail.535.13.25.24.1091.out ../run/400.perlbench/train/output/splitmail.535.13.25.24.1091.out
diff -w ../run/400.perlbench/train/input/splitmail.535.13.25.24.1091.out ../run/400.perlbench/train/output/splitmail.535.13.25.24.1091.out
echo diff -w ../run/400.perlbench/train/input/suns.out ../run/400.perlbench/train/output/suns.out
diff -w ../run/400.perlbench/train/input/suns.out ../run/400.perlbench/train/output/suns.out
echo diff -w ../run/400.perlbench/train/input/validate ../run/400.perlbench/train/output/validate
diff -w ../run/400.perlbench/train/input/validate ../run/400.perlbench/train/output/validate
