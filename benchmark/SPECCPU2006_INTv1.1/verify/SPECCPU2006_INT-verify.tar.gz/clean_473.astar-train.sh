echo rm -f ../run/473.astar/train/input/BigLakes1024.out
rm -f ../run/473.astar/train/input/BigLakes1024.out
echo rm -f ../run/473.astar/train/input/rivers1.out
rm -f ../run/473.astar/train/input/rivers1.out
