echo rm -f ../run/445.gobmk/ref/input/13x13.out
rm -f ../run/445.gobmk/ref/input/13x13.out
echo rm -f ../run/445.gobmk/ref/input/nngs.out
rm -f ../run/445.gobmk/ref/input/nngs.out
echo rm -f ../run/445.gobmk/ref/input/score2.out
rm -f ../run/445.gobmk/ref/input/score2.out
echo rm -f ../run/445.gobmk/ref/input/trevorc.out
rm -f ../run/445.gobmk/ref/input/trevorc.out
echo rm -f ../run/445.gobmk/ref/input/trevord.out
rm -f ../run/445.gobmk/ref/input/trevord.out
