echo rm -f ../run/458.sjeng/train/input/train.out
rm -f ../run/458.sjeng/train/input/train.out
