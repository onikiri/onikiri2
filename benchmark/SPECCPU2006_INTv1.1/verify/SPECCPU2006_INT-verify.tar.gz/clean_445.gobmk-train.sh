echo rm -f ../run/445.gobmk/train/input/arb.out
rm -f ../run/445.gobmk/train/input/arb.out
echo rm -f ../run/445.gobmk/train/input/arend.out
rm -f ../run/445.gobmk/train/input/arend.out
echo rm -f ../run/445.gobmk/train/input/arion.out
rm -f ../run/445.gobmk/train/input/arion.out
echo rm -f ../run/445.gobmk/train/input/atari_atari.out
rm -f ../run/445.gobmk/train/input/atari_atari.out
echo rm -f ../run/445.gobmk/train/input/blunder.out
rm -f ../run/445.gobmk/train/input/blunder.out
echo rm -f ../run/445.gobmk/train/input/buzco.out
rm -f ../run/445.gobmk/train/input/buzco.out
echo rm -f ../run/445.gobmk/train/input/nicklas2.out
rm -f ../run/445.gobmk/train/input/nicklas2.out
echo rm -f ../run/445.gobmk/train/input/nicklas4.out
rm -f ../run/445.gobmk/train/input/nicklas4.out
