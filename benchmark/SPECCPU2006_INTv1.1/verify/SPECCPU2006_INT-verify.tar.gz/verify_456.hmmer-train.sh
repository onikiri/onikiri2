echo diff -w ../run/456.hmmer/train/input/leng100.out ../run/456.hmmer/train/output/leng100.out
diff -w ../run/456.hmmer/train/input/leng100.out ../run/456.hmmer/train/output/leng100.out
