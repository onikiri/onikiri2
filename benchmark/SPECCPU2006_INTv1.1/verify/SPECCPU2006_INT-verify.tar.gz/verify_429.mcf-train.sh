echo diff -w ../run/429.mcf/train/input/inp.out ../run/429.mcf/train/output/inp.out
diff -w ../run/429.mcf/train/input/inp.out ../run/429.mcf/train/output/inp.out
echo diff -w ../run/429.mcf/train/input/mcf.out ../run/429.mcf/train/output/mcf.out
diff -w ../run/429.mcf/train/input/mcf.out ../run/429.mcf/train/output/mcf.out
