echo diff -w ../run/471.omnetpp/train/input/omnetpp.log ../run/471.omnetpp/train/output/omnetpp.log
diff -w ../run/471.omnetpp/train/input/omnetpp.log ../run/471.omnetpp/train/output/omnetpp.log
echo diff -w ../run/471.omnetpp/train/input/omnetpp.sca ../run/471.omnetpp/train/output/omnetpp.sca
diff -w ../run/471.omnetpp/train/input/omnetpp.sca ../run/471.omnetpp/train/output/omnetpp.sca
