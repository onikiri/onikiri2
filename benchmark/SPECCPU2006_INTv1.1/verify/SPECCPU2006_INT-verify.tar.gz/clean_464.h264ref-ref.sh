echo rm -f ../run/464.h264ref/ref/input/foreman_ref_baseline_encodelog.out
rm -f ../run/464.h264ref/ref/input/foreman_ref_baseline_encodelog.out
echo rm -f ../run/464.h264ref/ref/input/foreman_ref_baseline_leakybucketparam.cfg
rm -f ../run/464.h264ref/ref/input/foreman_ref_baseline_leakybucketparam.cfg
echo rm -f ../run/464.h264ref/ref/input/foreman_ref_main_encodelog.out
rm -f ../run/464.h264ref/ref/input/foreman_ref_main_encodelog.out
echo rm -f ../run/464.h264ref/ref/input/foreman_ref_main_leakybucketparam.cfg
rm -f ../run/464.h264ref/ref/input/foreman_ref_main_leakybucketparam.cfg
echo rm -f ../run/464.h264ref/ref/input/sss_main_encodelog.out
rm -f ../run/464.h264ref/ref/input/sss_main_encodelog.out
echo rm -f ../run/464.h264ref/ref/input/sss_main_leakybucketparam.cfg
rm -f ../run/464.h264ref/ref/input/sss_main_leakybucketparam.cfg
