echo rm -f ../run/462.libquantum/train/input/train.out
rm -f ../run/462.libquantum/train/input/train.out
