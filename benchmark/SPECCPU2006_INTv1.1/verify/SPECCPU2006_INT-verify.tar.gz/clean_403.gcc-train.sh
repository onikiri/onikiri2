echo rm -f ../run/403.gcc/train/input/integrate.s
rm -f ../run/403.gcc/train/input/integrate.s
