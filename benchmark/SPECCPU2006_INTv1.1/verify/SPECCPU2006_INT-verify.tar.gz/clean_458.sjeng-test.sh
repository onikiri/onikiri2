echo rm -f ../run/458.sjeng/test/input/test.out
rm -f ../run/458.sjeng/test/input/test.out
