echo rm -f ../run/471.omnetpp/train/input/omnetpp.log
rm -f ../run/471.omnetpp/train/input/omnetpp.log
echo rm -f ../run/471.omnetpp/train/input/omnetpp.sca
rm -f ../run/471.omnetpp/train/input/omnetpp.sca
