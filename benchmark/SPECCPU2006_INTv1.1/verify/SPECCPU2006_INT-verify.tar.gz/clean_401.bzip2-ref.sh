echo rm -f ../run/401.bzip2/ref/input/chicken.jpg.out
rm -f ../run/401.bzip2/ref/input/chicken.jpg.out
echo rm -f ../run/401.bzip2/ref/input/input.combined.out
rm -f ../run/401.bzip2/ref/input/input.combined.out
echo rm -f ../run/401.bzip2/ref/input/input.program.out
rm -f ../run/401.bzip2/ref/input/input.program.out
echo rm -f ../run/401.bzip2/ref/input/input.source.out
rm -f ../run/401.bzip2/ref/input/input.source.out
echo rm -f ../run/401.bzip2/ref/input/liberty.jpg.out
rm -f ../run/401.bzip2/ref/input/liberty.jpg.out
echo rm -f ../run/401.bzip2/ref/input/text.html.out
rm -f ../run/401.bzip2/ref/input/text.html.out
