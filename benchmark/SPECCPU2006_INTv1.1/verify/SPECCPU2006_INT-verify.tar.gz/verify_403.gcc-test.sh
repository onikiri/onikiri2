echo diff -w ../run/403.gcc/test/input/cccp.s ../run/403.gcc/test/output/cccp.s
diff -w ../run/403.gcc/test/input/cccp.s ../run/403.gcc/test/output/cccp.s
