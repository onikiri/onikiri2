echo diff -w ../run/473.astar/test/input/lake.out ../run/473.astar/test/output/lake.out
diff -w ../run/473.astar/test/input/lake.out ../run/473.astar/test/output/lake.out
