echo diff -w ../run/462.libquantum/test/input/test.out ../run/462.libquantum/test/output/test.out
diff -w ../run/462.libquantum/test/input/test.out ../run/462.libquantum/test/output/test.out
