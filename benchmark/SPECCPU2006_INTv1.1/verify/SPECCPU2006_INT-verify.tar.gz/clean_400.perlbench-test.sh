echo rm -f ../run/400.perlbench/test/input/append.out
rm -f ../run/400.perlbench/test/input/append.out
echo rm -f ../run/400.perlbench/test/input/args.out
rm -f ../run/400.perlbench/test/input/args.out
echo rm -f ../run/400.perlbench/test/input/arith.out
rm -f ../run/400.perlbench/test/input/arith.out
echo rm -f ../run/400.perlbench/test/input/array.out
rm -f ../run/400.perlbench/test/input/array.out
echo rm -f ../run/400.perlbench/test/input/attrs.out
rm -f ../run/400.perlbench/test/input/attrs.out
echo rm -f ../run/400.perlbench/test/input/auto.out
rm -f ../run/400.perlbench/test/input/auto.out
echo rm -f ../run/400.perlbench/test/input/base_cond.out
rm -f ../run/400.perlbench/test/input/base_cond.out
echo rm -f ../run/400.perlbench/test/input/base_pat.out
rm -f ../run/400.perlbench/test/input/base_pat.out
echo rm -f ../run/400.perlbench/test/input/base_term.out
rm -f ../run/400.perlbench/test/input/base_term.out
echo rm -f ../run/400.perlbench/test/input/bless.out
rm -f ../run/400.perlbench/test/input/bless.out
echo rm -f ../run/400.perlbench/test/input/bop.out
rm -f ../run/400.perlbench/test/input/bop.out
echo rm -f ../run/400.perlbench/test/input/bproto.out
rm -f ../run/400.perlbench/test/input/bproto.out
echo rm -f ../run/400.perlbench/test/input/chars.out
rm -f ../run/400.perlbench/test/input/chars.out
echo rm -f ../run/400.perlbench/test/input/chop.out
rm -f ../run/400.perlbench/test/input/chop.out
echo rm -f ../run/400.perlbench/test/input/cmdopt.out
rm -f ../run/400.perlbench/test/input/cmdopt.out
echo rm -f ../run/400.perlbench/test/input/cmp.out
rm -f ../run/400.perlbench/test/input/cmp.out
echo rm -f ../run/400.perlbench/test/input/comp_term.out
rm -f ../run/400.perlbench/test/input/comp_term.out
echo rm -f ../run/400.perlbench/test/input/concat.out
rm -f ../run/400.perlbench/test/input/concat.out
echo rm -f ../run/400.perlbench/test/input/context.out
rm -f ../run/400.perlbench/test/input/context.out
echo rm -f ../run/400.perlbench/test/input/decl.out
rm -f ../run/400.perlbench/test/input/decl.out
echo rm -f ../run/400.perlbench/test/input/defins.out
rm -f ../run/400.perlbench/test/input/defins.out
echo rm -f ../run/400.perlbench/test/input/delete.out
rm -f ../run/400.perlbench/test/input/delete.out
echo rm -f ../run/400.perlbench/test/input/die.out
rm -f ../run/400.perlbench/test/input/die.out
echo rm -f ../run/400.perlbench/test/input/do.out
rm -f ../run/400.perlbench/test/input/do.out
echo rm -f ../run/400.perlbench/test/input/each.out
rm -f ../run/400.perlbench/test/input/each.out
echo rm -f ../run/400.perlbench/test/input/eval.out
rm -f ../run/400.perlbench/test/input/eval.out
echo rm -f ../run/400.perlbench/test/input/exists_sub.out
rm -f ../run/400.perlbench/test/input/exists_sub.out
echo rm -f ../run/400.perlbench/test/input/exp.out
rm -f ../run/400.perlbench/test/input/exp.out
echo rm -f ../run/400.perlbench/test/input/fh.out
rm -f ../run/400.perlbench/test/input/fh.out
echo rm -f ../run/400.perlbench/test/input/grep.out
rm -f ../run/400.perlbench/test/input/grep.out
echo rm -f ../run/400.perlbench/test/input/gv.out
rm -f ../run/400.perlbench/test/input/gv.out
echo rm -f ../run/400.perlbench/test/input/hashwarn.out
rm -f ../run/400.perlbench/test/input/hashwarn.out
echo rm -f ../run/400.perlbench/test/input/if.out
rm -f ../run/400.perlbench/test/input/if.out
echo rm -f ../run/400.perlbench/test/input/inc.out
rm -f ../run/400.perlbench/test/input/inc.out
echo rm -f ../run/400.perlbench/test/input/index.out
rm -f ../run/400.perlbench/test/input/index.out
echo rm -f ../run/400.perlbench/test/input/int.out
rm -f ../run/400.perlbench/test/input/int.out
echo rm -f ../run/400.perlbench/test/input/join.out
rm -f ../run/400.perlbench/test/input/join.out
echo rm -f ../run/400.perlbench/test/input/length.out
rm -f ../run/400.perlbench/test/input/length.out
echo rm -f ../run/400.perlbench/test/input/lex.out
rm -f ../run/400.perlbench/test/input/lex.out
echo rm -f ../run/400.perlbench/test/input/list.out
rm -f ../run/400.perlbench/test/input/list.out
echo rm -f ../run/400.perlbench/test/input/loopctl.out
rm -f ../run/400.perlbench/test/input/loopctl.out
echo rm -f ../run/400.perlbench/test/input/lop.out
rm -f ../run/400.perlbench/test/input/lop.out
echo rm -f ../run/400.perlbench/test/input/makerand.out
rm -f ../run/400.perlbench/test/input/makerand.out
echo rm -f ../run/400.perlbench/test/input/method.out
rm -f ../run/400.perlbench/test/input/method.out
echo rm -f ../run/400.perlbench/test/input/my.out
rm -f ../run/400.perlbench/test/input/my.out
echo rm -f ../run/400.perlbench/test/input/nothr5005.out
rm -f ../run/400.perlbench/test/input/nothr5005.out
echo rm -f ../run/400.perlbench/test/input/oct.out
rm -f ../run/400.perlbench/test/input/oct.out
echo rm -f ../run/400.perlbench/test/input/op_cond.out
rm -f ../run/400.perlbench/test/input/op_cond.out
echo rm -f ../run/400.perlbench/test/input/op_pat.out
rm -f ../run/400.perlbench/test/input/op_pat.out
echo rm -f ../run/400.perlbench/test/input/ord.out
rm -f ../run/400.perlbench/test/input/ord.out
echo rm -f ../run/400.perlbench/test/input/override.out
rm -f ../run/400.perlbench/test/input/override.out
echo rm -f ../run/400.perlbench/test/input/pack.out
rm -f ../run/400.perlbench/test/input/pack.out
echo rm -f ../run/400.perlbench/test/input/package.out
rm -f ../run/400.perlbench/test/input/package.out
echo rm -f ../run/400.perlbench/test/input/pos.out
rm -f ../run/400.perlbench/test/input/pos.out
echo rm -f ../run/400.perlbench/test/input/push.out
rm -f ../run/400.perlbench/test/input/push.out
echo rm -f ../run/400.perlbench/test/input/quotemeta.out
rm -f ../run/400.perlbench/test/input/quotemeta.out
echo rm -f ../run/400.perlbench/test/input/range.out
rm -f ../run/400.perlbench/test/input/range.out
echo rm -f ../run/400.perlbench/test/input/recurse.out
rm -f ../run/400.perlbench/test/input/recurse.out
echo rm -f ../run/400.perlbench/test/input/redef.out
rm -f ../run/400.perlbench/test/input/redef.out
echo rm -f ../run/400.perlbench/test/input/ref.out
rm -f ../run/400.perlbench/test/input/ref.out
echo rm -f ../run/400.perlbench/test/input/regexp.out
rm -f ../run/400.perlbench/test/input/regexp.out
echo rm -f ../run/400.perlbench/test/input/regexp_noamp.out
rm -f ../run/400.perlbench/test/input/regexp_noamp.out
echo rm -f ../run/400.perlbench/test/input/regmesg.out
rm -f ../run/400.perlbench/test/input/regmesg.out
echo rm -f ../run/400.perlbench/test/input/repeat.out
rm -f ../run/400.perlbench/test/input/repeat.out
echo rm -f ../run/400.perlbench/test/input/reverse.out
rm -f ../run/400.perlbench/test/input/reverse.out
echo rm -f ../run/400.perlbench/test/input/rs.out
rm -f ../run/400.perlbench/test/input/rs.out
echo rm -f ../run/400.perlbench/test/input/sleep.out
rm -f ../run/400.perlbench/test/input/sleep.out
echo rm -f ../run/400.perlbench/test/input/sort.out
rm -f ../run/400.perlbench/test/input/sort.out
echo rm -f ../run/400.perlbench/test/input/splice.out
rm -f ../run/400.perlbench/test/input/splice.out
echo rm -f ../run/400.perlbench/test/input/study.out
rm -f ../run/400.perlbench/test/input/study.out
echo rm -f ../run/400.perlbench/test/input/sub_lval.out
rm -f ../run/400.perlbench/test/input/sub_lval.out
echo rm -f ../run/400.perlbench/test/input/subst.out
rm -f ../run/400.perlbench/test/input/subst.out
echo rm -f ../run/400.perlbench/test/input/subst_amp.out
rm -f ../run/400.perlbench/test/input/subst_amp.out
echo rm -f ../run/400.perlbench/test/input/subst_wamp.out
rm -f ../run/400.perlbench/test/input/subst_wamp.out
echo rm -f ../run/400.perlbench/test/input/tr.out
rm -f ../run/400.perlbench/test/input/tr.out
echo rm -f ../run/400.perlbench/test/input/undef.out
rm -f ../run/400.perlbench/test/input/undef.out
echo rm -f ../run/400.perlbench/test/input/unshift.out
rm -f ../run/400.perlbench/test/input/unshift.out
echo rm -f ../run/400.perlbench/test/input/vec.out
rm -f ../run/400.perlbench/test/input/vec.out
echo rm -f ../run/400.perlbench/test/input/wantarray.out
rm -f ../run/400.perlbench/test/input/wantarray.out
