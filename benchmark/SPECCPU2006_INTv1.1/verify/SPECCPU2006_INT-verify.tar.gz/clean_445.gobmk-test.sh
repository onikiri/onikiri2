echo rm -f ../run/445.gobmk/test/input/capture.out
rm -f ../run/445.gobmk/test/input/capture.out
echo rm -f ../run/445.gobmk/test/input/connect.out
rm -f ../run/445.gobmk/test/input/connect.out
echo rm -f ../run/445.gobmk/test/input/connect_rot.out
rm -f ../run/445.gobmk/test/input/connect_rot.out
echo rm -f ../run/445.gobmk/test/input/connection.out
rm -f ../run/445.gobmk/test/input/connection.out
echo rm -f ../run/445.gobmk/test/input/connection_rot.out
rm -f ../run/445.gobmk/test/input/connection_rot.out
echo rm -f ../run/445.gobmk/test/input/cutstone.out
rm -f ../run/445.gobmk/test/input/cutstone.out
echo rm -f ../run/445.gobmk/test/input/dniwog.out
rm -f ../run/445.gobmk/test/input/dniwog.out
