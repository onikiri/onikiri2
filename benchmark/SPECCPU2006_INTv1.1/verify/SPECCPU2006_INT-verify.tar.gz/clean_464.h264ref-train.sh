echo rm -f ../run/464.h264ref/train/input/foreman_train_baseline_encodelog.out
rm -f ../run/464.h264ref/train/input/foreman_train_baseline_encodelog.out
echo rm -f ../run/464.h264ref/train/input/foreman_train_baseline_leakybucketparam.cfg
rm -f ../run/464.h264ref/train/input/foreman_train_baseline_leakybucketparam.cfg
