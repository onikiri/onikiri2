echo diff -w ../run/464.h264ref/train/input/foreman_train_baseline_encodelog.out ../run/464.h264ref/train/output/foreman_train_baseline_encodelog.out
diff -w ../run/464.h264ref/train/input/foreman_train_baseline_encodelog.out ../run/464.h264ref/train/output/foreman_train_baseline_encodelog.out
echo diff -w ../run/464.h264ref/train/input/foreman_train_baseline_leakybucketparam.cfg ../run/464.h264ref/train/output/foreman_train_baseline_leakybucketparam.cfg
diff -w ../run/464.h264ref/train/input/foreman_train_baseline_leakybucketparam.cfg ../run/464.h264ref/train/output/foreman_train_baseline_leakybucketparam.cfg
