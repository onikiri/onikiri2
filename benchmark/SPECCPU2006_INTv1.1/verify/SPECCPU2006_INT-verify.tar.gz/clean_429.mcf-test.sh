echo rm -f ../run/429.mcf/test/input/inp.out
rm -f ../run/429.mcf/test/input/inp.out
echo rm -f ../run/429.mcf/test/input/mcf.out
rm -f ../run/429.mcf/test/input/mcf.out
