echo diff -w ../run/445.gobmk/test/input/capture.out ../run/445.gobmk/test/output/capture.out
diff -w ../run/445.gobmk/test/input/capture.out ../run/445.gobmk/test/output/capture.out
echo diff -w ../run/445.gobmk/test/input/connect.out ../run/445.gobmk/test/output/connect.out
diff -w ../run/445.gobmk/test/input/connect.out ../run/445.gobmk/test/output/connect.out
echo diff -w ../run/445.gobmk/test/input/connect_rot.out ../run/445.gobmk/test/output/connect_rot.out
diff -w ../run/445.gobmk/test/input/connect_rot.out ../run/445.gobmk/test/output/connect_rot.out
echo diff -w ../run/445.gobmk/test/input/connection.out ../run/445.gobmk/test/output/connection.out
diff -w ../run/445.gobmk/test/input/connection.out ../run/445.gobmk/test/output/connection.out
echo diff -w ../run/445.gobmk/test/input/connection_rot.out ../run/445.gobmk/test/output/connection_rot.out
diff -w ../run/445.gobmk/test/input/connection_rot.out ../run/445.gobmk/test/output/connection_rot.out
echo diff -w ../run/445.gobmk/test/input/cutstone.out ../run/445.gobmk/test/output/cutstone.out
diff -w ../run/445.gobmk/test/input/cutstone.out ../run/445.gobmk/test/output/cutstone.out
echo diff -w ../run/445.gobmk/test/input/dniwog.out ../run/445.gobmk/test/output/dniwog.out
diff -w ../run/445.gobmk/test/input/dniwog.out ../run/445.gobmk/test/output/dniwog.out
